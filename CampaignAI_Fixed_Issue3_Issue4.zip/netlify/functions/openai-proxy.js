// Netlify serverless function to proxy OpenAI API calls
// This keeps the API key secure on the server side

export default async (req, context) => {
  // Enable CORS for all origins
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle preflight OPTIONS request
  if (req.method === 'OPTIONS') {
    return new Response('', {
      status: 200,
      headers
  }

  // Only allow POST requests
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers
  }

  try {
    // Get the OpenAI API key from environment variables
    // Try multiple access methods for Netlify compatibility
    const OPENAI_API_KEY = Netlify.env.get('OPENAI_API_KEY') || 
                           process.env.OPENAI_API_KEY || 
                           context?.env?.OPENAI_API_KEY;
    
    // Debug logging
    console.log('Environment check:', {
      hasApiKey: !!OPENAI_API_KEY,
      keyLength: OPENAI_API_KEY ? OPENAI_API_KEY.length : 0,
      envKeys: Object.keys(process.env).filter(k => k.includes('OPENAI')),
      nodeVersion: process.version,
      netlifyEnvAvailable: typeof Netlify !== 'undefined'
    
    if (!OPENAI_API_KEY) {
      console.error('OPENAI_API_KEY environment variable is not set');
      console.error('Available env vars:', Object.keys(process.env).join(', '));
      return new Response(JSON.stringify({ 
        error: 'OpenAI API key not configured',
        hint: 'Please add OPENAI_API_KEY to Netlify environment variables with Functions scope'
      }), {
        status: 500,
        headers
    }

    // Parse the request body
    const requestBody = await req.json();
    const { endpoint, data } = requestBody;

    console.log('Request details:', { endpoint, dataKeys: Object.keys(data || {}) });

    // Validate the endpoint
    const allowedEndpoints = ['/chat/completions', '/images/generations'];
    if (!allowedEndpoints.includes(endpoint)) {
      return new Response(JSON.stringify({ error: 'Invalid endpoint' }), {
        status: 400,
        headers
    }

    // Make the request to OpenAI API using built-in fetch
    console.log(`Making request to: https://api.openai.com/v1${endpoint}`);
    
    const response = await fetch(`https://api.openai.com/v1${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify(data)

    const responseData = await response.json();

    if (!response.ok) {
      console.error('OpenAI API error:', response.status, responseData);
      return new Response(JSON.stringify({ 
        error: 'OpenAI API error', 
        details: responseData 
      }), {
        status: response.status,
        headers
    }

    console.log('OpenAI API request successful');
    return new Response(JSON.stringify(responseData), {
      status: 200,
      headers

  } catch (error) {
    console.error('Proxy error:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      message: error.message 
    }), {
      status: 500,
      headers
  }
};

export const config = {
  path: "/api/openai-proxy"
};
