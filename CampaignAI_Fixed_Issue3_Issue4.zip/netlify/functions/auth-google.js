const jwt = require('jsonwebtoken');
const { MongoClient } = require('mongodb');
const { sendWelcomeEmail } = require('./utils/emailService');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/campaignai';
const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID;
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET;
const APP_URL = process.env.APP_URL || 'http://localhost:8888';

let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const client = await MongoClient.connect(MONGODB_URI);
  const db = client.db('campaignai');
  cachedDb = db;
  return db;
}

async function verifyGoogleToken(credential) {
  try {
    // Verify the Google ID token
    const response = await fetch(
      `https://oauth2.googleapis.com/tokeninfo?id_token=${credential}`
    );

    if (!response.ok) {
      throw new Error('Invalid Google token');
    }

    const data = await response.json();

    // Verify the token is for our app
    if (data.aud !== GOOGLE_CLIENT_ID) {
      throw new Error('Token audience mismatch');
    }

    return {
      email: data.email,
      name: data.name,
      picture: data.picture,
      emailVerified: data.email_verified === 'true',
      googleId: data.sub,
    };
  } catch (error) {
    console.error('Google token verification error:', error);
    throw error;
  }
}

exports.handler = async (event) => {
  // Handle OPTIONS for CORS
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
      },
      body: '',
    };
  }

  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ message: 'Method not allowed' }),
    };
  }

  try {
    const { credential } = JSON.parse(event.body);

    if (!credential) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ message: 'Google credential is required' }),
      };
    }

    // Verify Google token
    const googleUser = await verifyGoogleToken(credential);

    // Connect to database
    const db = await connectToDatabase();
    const users = db.collection('users');

    // Check if user exists
    let user = await users.findOne({ email: googleUser.email.toLowerCase() });

    if (user) {
      // Existing user - update Google info if not set
      if (!user.googleId) {
        await users.updateOne(
          { _id: user._id },
          {
            $set: {
              googleId: googleUser.googleId,
              picture: googleUser.picture,
              emailVerified: true, // Google emails are pre-verified
              updatedAt: new Date(),
            },
          }
        );
        user.googleId = googleUser.googleId;
        user.picture = googleUser.picture;
      }
    } else {
      // New user - create account
      const newUser = {
        name: googleUser.name,
        email: googleUser.email.toLowerCase(),
        googleId: googleUser.googleId,
        picture: googleUser.picture,
        emailVerified: true, // Google emails are pre-verified
        password: null, // No password for Google SSO users
        subscription: {
          tier: 'Freemium',
          status: 'active',
          stripeCustomerId: null,
          stripeSubscriptionId: null,
        },
        usage: {
          campaignsUsed: 0,
          campaignsLimit: 1,
          periodStart: new Date(),
          periodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const result = await users.insertOne(newUser);
      user = { ...newUser, _id: result.insertedId };

      // Send welcome email (non-blocking)
      sendWelcomeEmail(user.name, user.email).catch(err => {
        console.error('Failed to send welcome email:', err);
      });
    }

    // Generate JWT
    const token = jwt.sign(
      { userId: user._id, email: user.email },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Return user data (without password)
    const userResponse = {
      id: user._id,
      name: user.name,
      email: user.email,
      picture: user.picture,
      subscription: user.subscription,
      usage: user.usage,
    };

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        message: 'Authentication successful',
        token,
        user: userResponse,
      }),
    };
  } catch (error) {
    console.error('Google auth error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ 
        message: 'Authentication failed',
        error: error.message 
      }),
    };
  }
};

