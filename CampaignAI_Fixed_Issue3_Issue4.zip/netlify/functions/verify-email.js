const { MongoClient } = require('mongodb');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/campaignai';

let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const client = await MongoClient.connect(MONGODB_URI);
  const db = client.db('campaignai');
  cachedDb = db;
  return db;
}

exports.handler = async (event) => {
  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ message: 'Method not allowed' }),
    };
  }

  try {
    const { token } = JSON.parse(event.body);

    if (!token) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ message: 'Verification token is required' }),
      };
    }

    // Connect to database
    const db = await connectToDatabase();
    const users = db.collection('users');

    // Find user with this verification token
    const user = await users.findOne({
      verificationToken: token,
      verificationExpiry: { $gt: new Date() }, // Token not expired
    });

    if (!user) {
      return {
        statusCode: 400,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ 
          message: 'Invalid or expired verification token' 
        }),
      };
    }

    // Update user as verified
    await users.updateOne(
      { _id: user._id },
      {
        $set: {
          emailVerified: true,
          verificationToken: null,
          verificationExpiry: null,
          updatedAt: new Date(),
        },
      }
    );

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        message: 'Email verified successfully',
        user: {
          name: user.name,
          email: user.email,
          emailVerified: true,
        },
      }),
    };
  } catch (error) {
    console.error('Email verification error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ 
        message: 'Failed to verify email',
        error: error.message 
      }),
    };
  }
};

