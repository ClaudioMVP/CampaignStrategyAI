// Netlify serverless function to proxy OpenAI API calls
// Updated to use modern ES modules and built-in fetch

export const handler = async (event, context) => {
  // Enable CORS for all origins
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  // Handle preflight OPTIONS request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: ''
    };
  }

  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    // Get the OpenAI API key from environment variables
    const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
    
    console.log('Environment check:', {
      hasApiKey: !!OPENAI_API_KEY,
      keyLength: OPENAI_API_KEY ? OPENAI_API_KEY.length : 0,
      nodeVersion: process.version
    });
    
    if (!OPENAI_API_KEY) {
      console.error('OPENAI_API_KEY environment variable is not set');
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: 'OpenAI API key not configured' })
      };
    }

    // Parse the request body
    let requestBody;
    try {
      requestBody = JSON.parse(event.body);
    } catch (parseError) {
      console.error('Failed to parse request body:', parseError);
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid JSON in request body' })
      };
    }

    const { endpoint, data } = requestBody;

    console.log('Request details:', { 
      endpoint, 
      dataKeys: Object.keys(data || {}),
      bodyLength: event.body?.length || 0
    });

    // Validate the endpoint
    const allowedEndpoints = ['/chat/completions', '/images/generations'];
    if (!allowedEndpoints.includes(endpoint)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Invalid endpoint' })
      };
    }

    // Validate required data
    if (!data) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Missing data in request' })
      };
    }

    // Make the request to OpenAI API using built-in fetch
    const openaiUrl = `https://api.openai.com/v1${endpoint}`;
    console.log(`Making request to: ${openaiUrl}`);
    
    const fetchOptions = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'User-Agent': 'Campaign-Strategy-AI/1.0'
      },
      body: JSON.stringify(data)
    };

    console.log('Fetch options:', {
      method: fetchOptions.method,
      headers: Object.keys(fetchOptions.headers),
      bodyLength: fetchOptions.body.length
    });

    const response = await fetch(openaiUrl, fetchOptions);

    console.log('OpenAI response status:', response.status, response.statusText);

    let responseData;
    try {
      responseData = await response.json();
    } catch (jsonError) {
      console.error('Failed to parse OpenAI response as JSON:', jsonError);
      const textResponse = await response.text();
      console.error('Raw response:', textResponse.substring(0, 500));
      
      return {
        statusCode: 502,
        headers,
        body: JSON.stringify({ 
          error: 'Invalid response from OpenAI API',
          details: 'Response was not valid JSON'
        })
      };
    }

    if (!response.ok) {
      console.error('OpenAI API error:', response.status, responseData);
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({ 
          error: 'OpenAI API error', 
          details: responseData,
          status: response.status
        })
      };
    }

    console.log('OpenAI API request successful');
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(responseData)
    };

  } catch (error) {
    console.error('Proxy error:', error);
    console.error('Error stack:', error.stack);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        error: 'Internal server error',
        message: error.message,
        type: error.name
      })
    };
  }
};
