// AI Service for Campaign Strategy MVP
// This module handles all AI-powered recommendations and content generation
// Updated to use Netlify serverless function proxy for secure API calls

class AIService {
  constructor() {
    // Use the Netlify function endpoint for API calls
    this.proxyEndpoint = '/.netlify/functions/openai-proxy';
  }

  async callOpenAI(messages, temperature = 0.7, maxTokens = 1500) {
    try {
      console.log('Making OpenAI API call via proxy...');
      
      const requestBody = {
        endpoint: '/chat/completions',
        data: {
          model: 'gpt-4',
          messages: messages,
          temperature: temperature,
          max_tokens: maxTokens
        }
      };

      const response = await fetch(this.proxyEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });

      console.log('Proxy response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Proxy error response:', errorText);
        throw new Error(`Proxy API error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      
      if (!data.choices || !data.choices[0] || !data.choices[0].message) {
        console.error('Invalid response structure:', data);
        throw new Error('Invalid response structure from OpenAI API');
      }

      console.log('OpenAI API call successful');
      return data.choices[0].message.content;
    } catch (error) {
      console.error('AI Service Error:', error);
      throw error;
    }
  }

  async callOpenAIImageGeneration(prompt, size = '1024x1024') {
    try {
      console.log('Generating image with prompt:', prompt.substring(0, 100) + '...');
      
      const requestBody = {
        endpoint: '/images/generations',
        data: {
          model: 'dall-e-3',
          prompt: prompt,
          n: 1,
          size: size,
          quality: 'standard'
        }
      };

      const response = await fetch(this.proxyEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });

      console.log('Image generation proxy response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Image generation HTTP error:', response.status, errorText);
        throw new Error(`Image generation error: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      
      if (!data.data || !data.data[0] || !data.data[0].url) {
        console.error('Invalid image response structure:', data);
        throw new Error('Invalid response structure from OpenAI Images API');
      }

      console.log('Image generation successful, URL received');
      return data.data[0].url;
    } catch (error) {
      console.error('Image Generation Error:', error);
      // Return a fallback placeholder image URL instead of throwing
      return 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlIEdlbmVyYXRpb24gRmFpbGVkPC90ZXh0Pjwvc3ZnPg==';
    }
  }

  async generateChannelRecommendations(campaignData) {
    const { campaignGoal, businessDescription, audienceDescription, budget, targetAreas } = campaignData;
    
    // Generate truly dynamic recommendations based on user inputs
    return this.generateDynamicChannelRecommendations(campaignData);
  }

  generateDynamicChannelRecommendations(campaignData) {
    const { campaignGoal, businessDescription, audienceDescription, budget, targetAreas } = campaignData;
    
    // Analyze the inputs to generate personalized recommendations
    const channels = [];
    const budgetNum = parseInt(budget) || 5000;
    
    // Analyze audience description for key indicators
    const audienceLower = audienceDescription.toLowerCase();
    const businessLower = businessDescription.toLowerCase();
    const goalLower = campaignGoal.toLowerCase();
    
    // Channel scoring based on audience and business characteristics
    const channelScores = {
      'LinkedIn Ads': this.scoreChannel('linkedin', audienceLower, businessLower, goalLower),
      'Google Search Ads': this.scoreChannel('google', audienceLower, businessLower, goalLower),
      'Email Marketing': this.scoreChannel('email', audienceLower, businessLower, goalLower),
      'Facebook/Meta Ads': this.scoreChannel('facebook', audienceLower, businessLower, goalLower),
      'Content Marketing': this.scoreChannel('content', audienceLower, businessLower, goalLower),
      'Industry Publications': this.scoreChannel('publications', audienceLower, businessLower, goalLower),
      'Webinars & Events': this.scoreChannel('events', audienceLower, businessLower, goalLower),
      'Direct Mail': this.scoreChannel('directmail', audienceLower, businessLower, goalLower)
    };
    
    // Sort channels by score and take top 3
    const sortedChannels = Object.entries(channelScores)
      .sort(([,a], [,b]) => b.score - a.score)
      .slice(0, 3);
    
    return sortedChannels.map(([name, data], index) => ({
      name: name,
      confidence: Math.round(Math.min(95, Math.max(70, data.score + Math.random() * 10))),
      reason: this.generateChannelReason(name, audienceDescription, businessDescription, campaignGoal),
      budgetAllocation: this.generateBudgetAllocation(name, budgetNum, index),
      audienceInsight: this.generateAudienceInsight(name, audienceDescription)
    }));
  }

  scoreChannel(channelType, audience, business, goal) {
    let score = 50; // Base score
    
    switch(channelType) {
      case 'linkedin':
        if (audience.includes('b2b') || audience.includes('professional') || audience.includes('decision maker') || 
            audience.includes('executive') || audience.includes('manager') || audience.includes('director')) score += 30;
        if (business.includes('b2b') || business.includes('saas') || business.includes('software') || 
            business.includes('consulting') || business.includes('service')) score += 20;
        if (goal.includes('lead') || goal.includes('awareness') || goal.includes('professional')) score += 15;
        break;
        
      case 'google':
        if (audience.includes('search') || audience.includes('research') || audience.includes('compare') || 
            audience.includes('solution') || audience.includes('problem')) score += 25;
        if (goal.includes('lead') || goal.includes('conversion') || goal.includes('sales')) score += 20;
        if (business.includes('ecommerce') || business.includes('retail') || business.includes('service')) score += 15;
        break;
        
      case 'email':
        if (audience.includes('existing') || audience.includes('customer') || audience.includes('subscriber') || 
            audience.includes('nurture') || audience.includes('relationship')) score += 25;
        if (goal.includes('retention') || goal.includes('nurture') || goal.includes('engagement')) score += 20;
        break;
        
      case 'facebook':
        if (audience.includes('consumer') || audience.includes('b2c') || audience.includes('lifestyle') || 
            audience.includes('personal') || audience.includes('social')) score += 25;
        if (business.includes('b2c') || business.includes('retail') || business.includes('consumer')) score += 20;
        break;
        
      case 'content':
        if (audience.includes('research') || audience.includes('education') || audience.includes('learn') || 
            audience.includes('information') || audience.includes('expert')) score += 25;
        if (goal.includes('awareness') || goal.includes('education') || goal.includes('thought leadership')) score += 20;
        break;
        
      case 'publications':
        if (audience.includes('industry') || audience.includes('trade') || audience.includes('specialist') || 
            audience.includes('professional') || audience.includes('expert')) score += 25;
        if (business.includes('niche') || business.includes('specialist') || business.includes('industry')) score += 20;
        break;
        
      case 'events':
        if (audience.includes('network') || audience.includes('conference') || audience.includes('event') || 
            audience.includes('meeting') || audience.includes('presentation')) score += 25;
        if (goal.includes('awareness') || goal.includes('relationship') || goal.includes('demo')) score += 20;
        break;
        
      case 'directmail':
        if (audience.includes('local') || audience.includes('traditional') || audience.includes('offline') || 
            audience.includes('physical') || audience.includes('tangible')) score += 20;
        if (business.includes('local') || business.includes('traditional') || business.includes('physical')) score += 15;
        break;
    }
    
    return { score: Math.min(100, score) };
  }

  generateChannelReason(channelName, audience, business, goal) {
    const reasons = {
      'LinkedIn Ads': [
        `Ideal for reaching professional decision-makers who actively use LinkedIn for business networking and industry insights.`,
        `Perfect for B2B targeting as professionals trust LinkedIn for business solutions and thought leadership content.`,
        `Highly effective for reaching executives and managers who engage with professional content on the platform.`
      ],
      'Google Search Ads': [
        `Captures high-intent users actively searching for solutions at the exact moment they need them.`,
        `Targets prospects who are researching options and ready to make purchasing decisions.`,
        `Reaches customers with specific search intent and immediate solution needs.`
      ],
      'Email Marketing': [
        `Enables direct, personalized communication with prospects and existing customers.`,
        `Perfect for nurturing leads through the decision-making process with targeted content.`,
        `Builds long-term relationships and trust through consistent, valuable communication.`
      ],
      'Facebook/Meta Ads': [
        `Reaches consumers during personal browsing time with engaging visual content and social proof.`,
        `Effective for building brand awareness through lifestyle-focused messaging and community engagement.`,
        `Great for targeting specific demographics with precise audience segmentation capabilities.`
      ],
      'Content Marketing': [
        `Establishes thought leadership and builds trust through valuable, educational content.`,
        `Attracts prospects who research thoroughly before making business decisions.`,
        `Drives organic traffic and positions your brand as an industry expert.`
      ],
      'Industry Publications': [
        `Reaches target audience through trusted industry sources they regularly read and respect.`,
        `Positions your brand alongside other respected companies in relevant trade publications.`,
        `Builds credibility through association with established industry media channels.`
      ],
      'Webinars & Events': [
        `Engages prospects through interactive, educational experiences and live demonstrations.`,
        `Perfect for building personal connections and showcasing expertise in real-time.`,
        `Allows for direct Q&A and relationship building with potential customers.`
      ],
      'Direct Mail': [
        `Stands out from digital noise with tangible, memorable materials that recipients can keep.`,
        `Effective for local targeting and reaching audiences who value personal, physical communication.`,
        `Creates lasting brand impressions through high-quality, tactile marketing materials.`
      ]
    };
    
    const channelReasons = reasons[channelName] || [`Effective channel for reaching your target audience with relevant messaging.`];
    return channelReasons[Math.floor(Math.random() * channelReasons.length)];
  }

  generateBudgetAllocation(channelName, totalBudget, priority) {
    const allocations = {
      'LinkedIn Ads': { min: 0.3, max: 0.5 },
      'Google Search Ads': { min: 0.25, max: 0.45 },
      'Email Marketing': { min: 0.1, max: 0.25 },
      'Facebook/Meta Ads': { min: 0.2, max: 0.4 },
      'Content Marketing': { min: 0.15, max: 0.3 },
      'Industry Publications': { min: 0.2, max: 0.35 },
      'Webinars & Events': { min: 0.25, max: 0.4 },
      'Direct Mail': { min: 0.15, max: 0.3 }
    };
    
    const allocation = allocations[channelName] || { min: 0.2, max: 0.4 };
    const percentage = priority === 0 ? allocation.max : (priority === 1 ? (allocation.min + allocation.max) / 2 : allocation.min);
    const amount = Math.round(totalBudget * percentage);
    
    return `${Math.round(percentage * 100)}% of budget (£${amount.toLocaleString()}/month) for ${channelName.toLowerCase()} campaigns and optimization`;
  }

  generateAudienceInsight(channelName, audience) {
    const insights = {
      'LinkedIn Ads': [
        `Professionals engage with industry content during business hours and respond to solution-focused messaging.`,
        `This audience uses LinkedIn for professional development and trusts peer recommendations.`,
        `Decision-makers prefer data-driven content and industry insights when evaluating solutions.`
      ],
      'Google Search Ads': [
        `Users research extensively before decisions, comparing options and reading reviews.`,
        `This audience uses specific search terms and responds to clear value propositions.`,
        `Prospects prefer landing pages that directly address their search intent.`
      ],
      'Email Marketing': [
        `Audience prefers personalized communication that demonstrates understanding of their challenges.`,
        `This group values regular, valuable content about industry trends and solutions.`,
        `Responds better to segmented, targeted emails rather than generic communications.`
      ],
      'Facebook/Meta Ads': [
        `Users engage with visual, story-driven content that connects emotionally with their goals.`,
        `This audience uses social media for both personal and professional purposes.`,
        `Trust social proof, testimonials, and peer recommendations when evaluating solutions.`
      ],
      'Content Marketing': [
        `Audience actively seeks educational content to stay current with industry trends.`,
        `This group shares valuable content with their networks, amplifying organic reach.`,
        `Prefers in-depth, expert-level content that provides actionable insights.`
      ],
      'Industry Publications': [
        `Regularly reads industry publications to stay informed about market trends and best practices.`,
        `This audience trusts established publications and views advertising as credible endorsements.`,
        `Often references industry publications when making business decisions.`
      ],
      'Webinars & Events': [
        `Values face-to-face interaction and prefers live demonstrations and Q&A sessions.`,
        `This audience uses events for networking and professional development opportunities.`,
        `Appreciates the opportunity to ask specific questions and see real-time demonstrations.`
      ],
      'Direct Mail': [
        `Appreciates tangible materials that can be referenced later and shared with colleagues.`,
        `This audience values the personal touch and sees it as a sign of professionalism.`,
        `Often keeps physical materials for future reference, providing longer brand exposure.`
      ]
    };
    
    const channelInsights = insights[channelName] || [`This audience engages with the channel based on their specific professional needs.`];
    return channelInsights[Math.floor(Math.random() * channelInsights.length)];
  }

  async generateTacticRecommendations(campaignData) {
    const { campaignGoal, businessDescription, audienceDescription, budget } = campaignData;
    
    // Generate truly dynamic tactics based on user inputs
    return this.generateDynamicTactics(campaignData);
  }

  generateDynamicTactics(campaignData) {
    const { campaignGoal, businessDescription, audienceDescription, budget } = campaignData;
    
    const audienceLower = audienceDescription.toLowerCase();
    const businessLower = businessDescription.toLowerCase();
    const goalLower = campaignGoal.toLowerCase();
    
    const tactics = [];
    
    // Generate tactics based on audience and business characteristics
    if (audienceLower.includes('b2b') || audienceLower.includes('professional') || audienceLower.includes('decision maker')) {
      tactics.push(`Create thought leadership content addressing industry challenges and decision-making processes`);
      tactics.push(`Develop case studies showcasing successful outcomes for similar businesses`);
    }
    
    if (audienceLower.includes('research') || audienceLower.includes('compare') || audienceLower.includes('evaluate')) {
      tactics.push(`Produce comparison guides and ROI calculators for evaluation criteria`);
      tactics.push(`Create comprehensive resource libraries addressing research needs`);
    }
    
    if (goalLower.includes('lead') || goalLower.includes('conversion') || goalLower.includes('sales')) {
      tactics.push(`Implement targeted retargeting campaigns for engaged prospects`);
      tactics.push(`Design conversion-optimized landing pages with clear value propositions`);
    }
    
    if (audienceLower.includes('social') || audienceLower.includes('network') || audienceLower.includes('community')) {
      tactics.push(`Build community engagement initiatives for customer connection and sharing`);
      tactics.push(`Leverage social proof and testimonials to build trust and credibility`);
    }
    
    if (audienceLower.includes('mobile') || audienceLower.includes('on-the-go') || audienceLower.includes('busy')) {
      tactics.push(`Optimize all content for mobile-first experience and quick consumption`);
      tactics.push(`Create bite-sized, easily digestible content for time-constrained audiences`);
    }
    
    // Add budget-specific tactics
    const budgetNum = parseInt(budget) || 5000;
    if (budgetNum > 10000) {
      tactics.push(`Implement advanced marketing automation workflows for personalized customer journeys`);
    } else if (budgetNum > 5000) {
      tactics.push(`Focus on high-impact, cost-effective channels with proven ROI`);
    } else {
      tactics.push(`Prioritize organic content marketing and community building for maximum reach`);
    }
    
    // Add goal-specific tactics
    if (goalLower.includes('awareness')) {
      tactics.push(`Develop shareable content that encourages organic amplification and brand visibility`);
    }
    
    if (goalLower.includes('retention')) {
      tactics.push(`Create loyalty programs and exclusive content for existing customers`);
    }
    
    // Ensure we have at least 5 tactics
    while (tactics.length < 5) {
      tactics.push(`Implement A/B testing across all campaigns to optimize performance and ROI`);
      tactics.push(`Create multi-touch attribution tracking to understand customer journey touchpoints`);
      tactics.push(`Develop personalized content experiences based on audience segment preferences`);
    }
    
    return tactics.slice(0, 6); // Return top 6 tactics
  }

  async generateAudiencePersona(campaignData) {
    const { campaignGoal, businessDescription, audienceDescription, companyName } = campaignData;
    
    const messages = [
      {
        role: 'system',
        content: `You are an expert marketing strategist who creates detailed audience personas. Create a realistic, specific persona based on the provided campaign information. The persona should feel like a real person with specific motivations, pain points, and preferences.`
      },
      {
        role: 'user',
        content: `Create a detailed audience persona for this campaign:

Company: ${companyName}
Business: ${businessDescription}
Campaign Goal: ${campaignGoal}
Target Audience: ${audienceDescription}

Return a JSON object with this exact structure:
{
  "name": "First Last",
  "role": "Job Title",
  "age": "Age range (e.g., 35-45)",
  "motivations": ["motivation 1", "motivation 2", "motivation 3"],
  "painPoints": ["pain point 1", "pain point 2", "pain point 3"],
  "preferredChannels": ["channel 1", "channel 2", "channel 3"]
}

Make the persona specific and realistic based on the audience description provided.`
      }
    ];

    try {
      const response = await this.callOpenAI(messages, 0.7, 800);
      const cleanedResponse = response.replace(/```json\n?|\n?```/g, '').trim();
      return JSON.parse(cleanedResponse);
    } catch (error) {
      console.error('Error generating persona:', error);
      // Fallback persona
      return {
        name: "Alex Johnson",
        role: "Marketing Manager",
        age: "30-40",
        motivations: ["Drive business growth", "Improve marketing ROI", "Stay ahead of competition"],
        painPoints: ["Limited marketing budget", "Difficulty measuring campaign effectiveness", "Time constraints"],
        preferredChannels: ["LinkedIn", "Email", "Industry publications"]
      };
    }
  }

  async generateMessagingAngles(campaignData, persona) {
    const { campaignGoal, businessDescription, companyName } = campaignData;
    
    const messages = [
      {
        role: 'system',
        content: `You are a creative marketing strategist who develops compelling messaging angles. Create 3 distinct messaging approaches that would resonate with the target persona and achieve the campaign goal.`
      },
      {
        role: 'user',
        content: `Create 3 messaging angles for this campaign:

Company: ${companyName}
Business: ${businessDescription}
Campaign Goal: ${campaignGoal}
Target Persona: ${persona.name} (${persona.role})
Persona Motivations: ${persona.motivations.join(', ')}
Persona Pain Points: ${persona.painPoints.join(', ')}

Return a JSON array with this exact structure:
[
  {
    "angle": "Messaging Angle Name",
    "headline": "Compelling headline",
    "description": "Brief description of the approach",
    "tone": "Professional/Friendly/Urgent/etc",
    "cta": "Call to action text"
  }
]

Make each angle distinct and tailored to the persona's motivations and pain points.`
      }
    ];

    try {
      const response = await this.callOpenAI(messages, 0.8, 1000);
      const cleanedResponse = response.replace(/```json\n?|\n?```/g, '').trim();
      return JSON.parse(cleanedResponse);
    } catch (error) {
      console.error('Error generating messaging angles:', error);
      // Fallback messaging angles
      return [
        {
          angle: "Problem-Solution Focus",
          headline: "Stop Wasting Time on Ineffective Marketing",
          description: "Address the main pain points directly and position your solution as the answer",
          tone: "Professional",
          cta: "Get Started Today"
        },
        {
          angle: "Results-Driven Approach",
          headline: "Proven Results That Drive Real Growth",
          description: "Focus on measurable outcomes and success stories",
          tone: "Confident",
          cta: "See Our Results"
        },
        {
          angle: "Innovation Leadership",
          headline: "Stay Ahead with Cutting-Edge Solutions",
          description: "Position as the innovative choice for forward-thinking professionals",
          tone: "Inspiring",
          cta: "Learn More"
        }
      ];
    }
  }

  async generateVisualThemes(campaignData, persona, messagingAngles) {
    const { businessDescription, companyName } = campaignData;
    
    const messages = [
      {
        role: 'system',
        content: `You are a creative director who develops visual themes for marketing campaigns. Create 3 distinct visual approaches that complement the messaging angles and appeal to the target persona.`
      },
      {
        role: 'user',
        content: `Create 3 visual themes for this campaign:

Company: ${companyName}
Business: ${businessDescription}
Target Persona: ${persona.name} (${persona.role})
Messaging Angles: ${messagingAngles.map(angle => angle.angle).join(', ')}

Return a JSON array with this exact structure:
[
  {
    "theme": "Visual Theme Name",
    "description": "Description of the visual approach",
    "mood": "Professional/Modern/Bold/etc"
  }
]

Make each theme visually distinct and appropriate for the business and persona.`
      }
    ];

    try {
      const response = await this.callOpenAI(messages, 0.8, 800);
      const cleanedResponse = response.replace(/```json\n?|\n?```/g, '').trim();
      return JSON.parse(cleanedResponse);
    } catch (error) {
      console.error('Error generating visual themes:', error);
      // Fallback visual themes
      return [
        {
          theme: "Clean Professional",
          description: "Minimalist design with professional typography and corporate colors",
          mood: "Professional"
        },
        {
          theme: "Modern Dynamic",
          description: "Contemporary design with bold colors and dynamic layouts",
          mood: "Energetic"
        },
        {
          theme: "Trustworthy Classic",
          description: "Traditional design elements that convey reliability and expertise",
          mood: "Trustworthy"
        }
      ];
    }
  }

  async generateCreativeVisual(messagingAngle, visualTheme, companyName, businessDescription, campaignGoal, audienceDescription, persona) {
    try {
      // Generate 3 creative concepts
      const concepts = await Promise.all([
        this.generateSingleCreative(messagingAngle, visualTheme, companyName, businessDescription, campaignGoal, audienceDescription, persona, 1),
        this.generateSingleCreative(messagingAngle, visualTheme, companyName, businessDescription, campaignGoal, audienceDescription, persona, 2),
        this.generateSingleCreative(messagingAngle, visualTheme, companyName, businessDescription, campaignGoal, audienceDescription, persona, 3)
      ]);

      return concepts;
    } catch (error) {
      console.error('Error generating creative visuals:', error);
      // Return fallback creatives
      return this.getFallbackCreatives(companyName, messagingAngle, visualTheme);
    }
  }

  async generateSingleCreative(messagingAngle, visualTheme, companyName, businessDescription, campaignGoal, audienceDescription, persona, conceptNumber) {
    // Generate creative concept details
    const messages = [
      {
        role: 'system',
        content: `You are a creative director developing advertising concepts. Create a specific creative concept that combines the messaging angle and visual theme effectively.`
      },
      {
        role: 'user',
        content: `Create creative concept #${conceptNumber} for this campaign:

Company: ${companyName}
Business: ${businessDescription}
Campaign Goal: ${campaignGoal}
Messaging Angle: ${messagingAngle.angle} - "${messagingAngle.headline}"
Visual Theme: ${visualTheme.theme} - ${visualTheme.description}
Target Persona: ${persona.name} (${persona.role})

Return a JSON object with this exact structure:
{
  "id": ${conceptNumber},
  "title": "Creative Concept Title",
  "approach": "Brief approach description",
  "headline": "Main headline text",
  "subCopy": "Supporting copy text",
  "cta": "Call to action",
  "narrative": "Creative narrative explanation",
  "visualStyle": "Visual style description",
  "layout": "Layout approach description"
}

Make this concept unique and compelling for the target audience.`
      }
    ];

    try {
      const conceptResponse = await this.callOpenAI(messages, 0.8, 800);
      const cleanedResponse = conceptResponse.replace(/```json\n?|\n?```/g, '').trim();
      const concept = JSON.parse(cleanedResponse);

      // Generate background image for this concept
      const imagePrompt = this.generateImagePrompt(concept, visualTheme, persona, businessDescription);
      const imageUrl = await this.callOpenAIImageGeneration(imagePrompt);

      return {
        ...concept,
        imageUrl: imageUrl
      };
    } catch (error) {
      console.error(`Error generating creative concept ${conceptNumber}:`, error);
      return this.getFallbackCreative(conceptNumber, companyName, messagingAngle, visualTheme);
    }
  }

  generateImagePrompt(concept, visualTheme, persona, businessDescription) {
    const basePrompt = `Create a professional marketing background image for a ${businessDescription.toLowerCase()} company. `;
    
    let stylePrompt = '';
    switch (visualTheme.mood.toLowerCase()) {
      case 'professional':
        stylePrompt = 'Clean, minimalist design with professional corporate aesthetic, subtle gradients, modern typography space. ';
        break;
      case 'energetic':
      case 'dynamic':
        stylePrompt = 'Dynamic, modern design with bold colors, geometric shapes, and energetic visual elements. ';
        break;
      case 'trustworthy':
        stylePrompt = 'Reliable, established look with classic design elements, professional color palette, and trustworthy visual cues. ';
        break;
      default:
        stylePrompt = 'Professional, modern design with clean aesthetics and business-appropriate styling. ';
    }

    const audiencePrompt = `Designed to appeal to ${persona.role.toLowerCase()}s and business professionals. `;
    const technicalPrompt = 'High quality, suitable for digital advertising, with space for text overlay, 16:9 aspect ratio, professional photography style.';

    return basePrompt + stylePrompt + audiencePrompt + technicalPrompt;
  }

  getFallbackCreatives(companyName, messagingAngle, visualTheme) {
    return [
      {
        id: 1,
        title: "Primary Value Proposition",
        approach: "Direct benefit focus",
        headline: messagingAngle.headline,
        subCopy: `Discover how ${companyName} can transform your business with proven solutions.`,
        cta: messagingAngle.cta,
        narrative: "Focuses on the primary value proposition with clear, direct messaging.",
        visualStyle: visualTheme.description,
        layout: "Centered text with strong visual hierarchy",
        imageUrl: "/creative-visual-roi-focused.png"
      },
      {
        id: 2,
        title: "Problem-Solution Focus",
        approach: "Challenge-based messaging",
        headline: "Overcome Your Biggest Challenges",
        subCopy: `${companyName} provides the solutions you need to succeed in today's market.`,
        cta: "Learn How",
        narrative: "Addresses specific pain points and positions the solution as the answer.",
        visualStyle: visualTheme.description,
        layout: "Problem-solution visual flow",
        imageUrl: "/creative-visual-competitive-advantage.png"
      },
      {
        id: 3,
        title: "Results-Driven Approach",
        approach: "Outcome-focused messaging",
        headline: "Proven Results You Can Trust",
        subCopy: `Join successful businesses who chose ${companyName} for measurable growth.`,
        cta: "See Results",
        narrative: "Emphasizes proven outcomes and success stories to build credibility.",
        visualStyle: visualTheme.description,
        layout: "Results-focused visual presentation",
        imageUrl: "/creative-visual-time-saving.png"
      }
    ];
  }

  getFallbackCreative(conceptNumber, companyName, messagingAngle, visualTheme) {
    const fallbacks = this.getFallbackCreatives(companyName, messagingAngle, visualTheme);
    return fallbacks[conceptNumber - 1] || fallbacks[0];
  }

  async generateCreativeBrief(campaignData, aiResults) {
    const { companyName, businessDescription, campaignGoal, audienceDescription, budget, targetAreas } = campaignData;
    const { messaging, recommendations } = aiResults;

    const messages = [
      {
        role: 'system',
        content: `You are a senior creative strategist creating comprehensive creative briefs for advertising agencies. Create a detailed, professional brief that follows industry standards and provides all necessary information for creative development.`
      },
      {
        role: 'user',
        content: `Create a comprehensive creative brief based on this campaign information:

CAMPAIGN DETAILS:
Company: ${companyName}
Business: ${businessDescription}
Campaign Goal: ${campaignGoal}
Budget: £${budget}/month
Target Areas: ${targetAreas}
Audience Description: ${audienceDescription}

PERSONA INSIGHTS:
Name: ${messaging?.persona?.name || 'Target Persona'}
Role: ${messaging?.persona?.role || 'Professional'}
Motivations: ${messaging?.persona?.motivations?.join(', ') || 'Business growth, efficiency, success'}
Pain Points: ${messaging?.persona?.painPoints?.join(', ') || 'Time constraints, budget limitations, competition'}

RECOMMENDED CHANNELS:
${recommendations?.channels?.map(channel => `- ${channel.name}: ${channel.reason}`).join('\n') || 'Digital marketing channels'}

Create a detailed creative brief in markdown format with these sections:
1. Executive Summary
2. Campaign Objectives
3. Target Audience Profile
4. Key Messages & Positioning
5. Creative Direction
6. Channel Strategy
7. Budget & Timeline
8. Success Metrics
9. Mandatories & Constraints

Make it comprehensive and agency-ready.`
      }
    ];

    try {
      const response = await this.callOpenAI(messages, 0.7, 2000);
      return response;
    } catch (error) {
      console.error('Error generating creative brief:', error);
      return this.getFallbackCreativeBrief(campaignData, aiResults);
    }
  }

  getFallbackCreativeBrief(campaignData, aiResults) {
    const { companyName, businessDescription, campaignGoal, audienceDescription, budget, targetAreas } = campaignData;
    
    return `# Creative Brief: ${companyName} Campaign

## Executive Summary
This creative brief outlines the strategic approach for ${companyName}'s upcoming marketing campaign focused on ${campaignGoal.toLowerCase()}. The campaign targets ${audienceDescription.toLowerCase()} with a monthly budget of £${budget}.

## Campaign Objectives
**Primary Goal:** ${campaignGoal}
**Target Market:** ${targetAreas}
**Budget:** £${budget}/month

## Target Audience Profile
**Primary Audience:** ${audienceDescription}
**Key Characteristics:**
- Professional decision-makers
- Value-driven and results-oriented
- Active in digital channels
- Seek trusted, proven solutions

## Key Messages & Positioning
**Primary Message:** ${companyName} delivers proven solutions that drive real business results
**Supporting Messages:**
- Trusted by professionals like you
- Measurable outcomes and ROI
- Expert guidance and support

## Creative Direction
**Tone:** Professional, trustworthy, results-focused
**Visual Style:** Clean, modern, professional
**Key Elements:** Clear value proposition, social proof, strong call-to-action

## Channel Strategy
**Primary Channels:**
- Digital advertising (LinkedIn, Google)
- Content marketing
- Email campaigns
- Industry publications

## Budget & Timeline
**Total Budget:** £${budget}/month
**Campaign Duration:** 3-6 months initial phase
**Key Milestones:** Launch, optimization, scaling

## Success Metrics
- Lead generation volume
- Cost per acquisition
- Conversion rates
- Brand awareness lift

## Mandatories & Constraints
- Maintain brand consistency
- Comply with industry regulations
- Focus on measurable outcomes
- Professional tone throughout

---
*Brief prepared for ${companyName} campaign strategy*`;
  }

  async generateMediaPublicationRecommendations(campaignData, persona) {
    const { campaignGoal, businessDescription, audienceDescription, targetAreas } = campaignData;
    
    const messages = [
      {
        role: 'system',
        content: `You are a media planning expert who recommends relevant publications for advertising and content placement. Analyze the campaign details and suggest credible publications that the target audience actually reads and trusts.`
      },
      {
        role: 'user',
        content: `Recommend media publications for this campaign:

Business: ${businessDescription}
Campaign Goal: ${campaignGoal}
Target Audience: ${audienceDescription}
Geographic Focus: ${targetAreas}
Target Persona: ${persona.name} (${persona.role})
Persona Interests: ${persona.motivations?.join(', ') || 'Professional development, business growth'}

Return a JSON array with this exact structure:
[
  {
    "name": "Publication Name",
    "reason": "Why this publication is relevant for the target audience"
  }
]

Focus on credible, well-known publications that the target audience would actually read. Include a mix of:
- Industry-specific publications
- Business/professional publications  
- Digital platforms
- Regional publications (if applicable)

Limit to 4-6 recommendations.`
      }
    ];

    try {
      const response = await this.callOpenAI(messages, 0.7, 1000);
      const cleanedResponse = response.replace(/```json\n?|\n?```/g, '').trim();
      return JSON.parse(cleanedResponse);
    } catch (error) {
      console.error('Error generating media publication recommendations:', error);
      return this.getFallbackMediaPublications(businessDescription, audienceDescription, targetAreas);
    }
  }

  getFallbackMediaPublications(businessDescription, audienceDescription, targetAreas) {
    const publications = [];
    
    // Business publications
    publications.push({
      name: "Harvard Business Review",
      reason: "Trusted by senior executives and decision-makers for strategic business insights and thought leadership."
    });
    
    publications.push({
      name: "Financial Times",
      reason: "Read by business professionals and executives who make purchasing decisions and value credible business news."
    });
    
    // Industry-specific based on business description
    if (businessDescription.toLowerCase().includes('tech') || businessDescription.toLowerCase().includes('software')) {
      publications.push({
        name: "TechCrunch",
        reason: "Leading technology publication read by tech professionals, entrepreneurs, and decision-makers in the industry."
      });
    }
    
    if (businessDescription.toLowerCase().includes('marketing') || businessDescription.toLowerCase().includes('advertising')) {
      publications.push({
        name: "Marketing Land",
        reason: "Essential reading for marketing professionals seeking industry insights and best practices."
      });
    }
    
    // Professional platforms
    publications.push({
      name: "LinkedIn Newsletter",
      reason: "Reaches professionals in their preferred business networking environment where they consume industry content."
    });
    
    // Regional if UK focused
    if (targetAreas.toLowerCase().includes('uk') || targetAreas.toLowerCase().includes('london')) {
      publications.push({
        name: "The Times Business Section",
        reason: "Trusted UK business publication read by senior professionals and decision-makers across industries."
      });
    }
    
    return publications.slice(0, 5);
  }
}

const aiService = new AIService();
export default aiService;

