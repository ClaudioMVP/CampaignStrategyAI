const jwt = require('jsonwebtoken');
const { MongoClient, ObjectId } = require('mongodb');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/campaignai';

let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const client = await MongoClient.connect(MONGODB_URI);
  const db = client.db('campaignai');
  cachedDb = db;
  return db;
}

exports.handler = async (event) => {
  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ message: 'Method not allowed' }),
    };
  }

  try {
    // Get token from Authorization header
    const authHeader = event.headers.authorization || event.headers.Authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return {
        statusCode: 401,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ message: 'Unauthorized - No token provided' }),
      };
    }

    const token = authHeader.substring(7);
    
    // Verify token
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (error) {
      return {
        statusCode: 401,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ message: 'Unauthorized - Invalid token' }),
      };
    }

    const { campaignData } = JSON.parse(event.body);

    // Connect to database
    const db = await connectToDatabase();
    const users = db.collection('users');
    const campaigns = db.collection('campaigns');

    // Get user
    const user = await users.findOne({ _id: new ObjectId(decoded.userId) });
    if (!user) {
      return {
        statusCode: 404,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ message: 'User not found' }),
      };
    }

    // Check campaign limit
    const currentUsage = user.usage?.campaignsUsed || 0;
    const limit = user.usage?.campaignsLimit || 1;

    if (currentUsage >= limit && limit !== -1) {
      return {
        statusCode: 403,
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({ 
          message: 'Campaign limit reached',
          currentUsage,
          limit,
          tier: user.subscription?.tier || 'freemium'
        }),
      };
    }

    // Save campaign to database
    const campaign = {
      userId: new ObjectId(decoded.userId),
      ...campaignData,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const result = await campaigns.insertOne(campaign);

    // Update user's campaign count
    await users.updateOne(
      { _id: new ObjectId(decoded.userId) },
      { 
        $inc: { 'usage.campaignsUsed': 1 },
        $set: { updatedAt: new Date() }
      }
    );

    // Get updated user
    const updatedUser = await users.findOne({ _id: new ObjectId(decoded.userId) });

    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({
        message: 'Campaign tracked successfully',
        campaignId: result.insertedId,
        campaignsUsed: updatedUser.usage.campaignsUsed,
        campaignLimit: updatedUser.usage.campaignsLimit,
        tier: updatedUser.subscription.tier
      }),
    };
  } catch (error) {
    console.error('Track campaign error:', error);
    return {
      statusCode: 500,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
      },
      body: JSON.stringify({ 
        message: 'Failed to track campaign',
        error: error.message 
      }),
    };
  }
};

