const { MongoClient, ObjectId } = require('mongodb');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/campaignai';
const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;

let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const client = await MongoClient.connect(MONGODB_URI);

  const db = client.db('campaignai');
  cachedDb = db;
  return db;
}

// Map tier names to campaign limits (3-tier system)
const TIER_LIMITS = {
  'Freemium': 1,
  'Starter': 5,
  'Professional': -1, // unlimited
};

exports.handler = async (event) => {
  // Only allow POST
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ message: 'Method not allowed' }),
    };
  }

  try {
    const sig = event.headers['stripe-signature'];
    let stripeEvent;

    // Verify webhook signature
    try {
      stripeEvent = stripe.webhooks.constructEvent(
        event.body,
        sig,
        WEBHOOK_SECRET
      );
    } catch (err) {
      console.error('Webhook signature verification failed:', err.message);
      return {
        statusCode: 400,
        body: JSON.stringify({ message: `Webhook Error: ${err.message}` }),
      };
    }

    const db = await connectToDatabase();
    const users = db.collection('users');

    // Handle the event
    switch (stripeEvent.type) {
      case 'checkout.session.completed': {
        console.log('=== CHECKOUT SESSION COMPLETED ===');
        const session = stripeEvent.data.object;
        console.log('Session ID:', session.id);
        console.log('Session metadata:', JSON.stringify(session.metadata));
        console.log('Session subscription:', session.subscription);
        
        const userId = session.metadata.userId;
        const tier = session.metadata.tier;
        const billingCycle = session.metadata.billingCycle;
        
        if (!userId) {
          console.error('ERROR: No userId in metadata');
          break;
        }
        
        if (!session.subscription) {
          console.error('ERROR: No subscription in session');
          break;
        }

        console.log(`Processing subscription for user ${userId}, tier: ${tier}`);

        // Get subscription details
        const subscription = await stripe.subscriptions.retrieve(session.subscription);
        console.log('Retrieved subscription:', subscription.id);

        // Update user subscription
        const result = await users.updateOne(
          { _id: new ObjectId(userId) },
          {
            $set: {
              'subscription.tier': tier,
              'subscription.status': 'active',
              'subscription.stripeSubscriptionId': subscription.id,
              'subscription.currentPeriodEnd': new Date(subscription.current_period_end * 1000),
              'subscription.billingCycle': billingCycle,
              'usage.campaignsLimit': TIER_LIMITS[tier] || 1,
              'usage.periodStart': new Date(subscription.current_period_start * 1000),
              'usage.periodEnd': new Date(subscription.current_period_end * 1000),
              updatedAt: new Date(),
            },
          }
        );
        
        console.log('Update result:', JSON.stringify(result));
        console.log(`✅ Subscription activated for user ${userId}: ${tier}, limit: ${TIER_LIMITS[tier]}`);
        break;
      }

      case 'customer.subscription.updated': {
        const subscription = stripeEvent.data.object;
        const customerId = subscription.customer;

        // Find user by Stripe customer ID
        const user = await users.findOne({ 'subscription.stripeCustomerId': customerId });
        if (!user) {
          console.error('User not found for customer:', customerId);
          break;
        }

        // Update subscription status
        await users.updateOne(
          { _id: user._id },
          {
            $set: {
              'subscription.status': subscription.status,
              'subscription.currentPeriodEnd': new Date(subscription.current_period_end * 1000),
              'usage.periodStart': new Date(subscription.current_period_start * 1000),
              'usage.periodEnd': new Date(subscription.current_period_end * 1000),
              updatedAt: new Date(),
            },
          }
        );

        console.log(`Subscription updated for user ${user._id}: ${subscription.status}`);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = stripeEvent.data.object;
        const customerId = subscription.customer;

        // Find user by Stripe customer ID
        const user = await users.findOne({ 'subscription.stripeCustomerId': customerId });
        if (!user) {
          console.error('User not found for customer:', customerId);
          break;
        }

        // Downgrade to Freemium
        await users.updateOne(
          { _id: user._id },
          {
            $set: {
              'subscription.tier': 'Freemium',
              'subscription.status': 'canceled',
              'subscription.stripeSubscriptionId': null,
              'usage.campaignsLimit': 1,
              updatedAt: new Date(),
            },
          }
        );

        console.log(`Subscription canceled for user ${user._id}`);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = stripeEvent.data.object;
        const customerId = invoice.customer;

        // Find user by Stripe customer ID
        const user = await users.findOne({ 'subscription.stripeCustomerId': customerId });
        if (!user) {
          console.error('User not found for customer:', customerId);
          break;
        }

        // Update subscription status
        await users.updateOne(
          { _id: user._id },
          {
            $set: {
              'subscription.status': 'past_due',
              updatedAt: new Date(),
            },
          }
        );

        console.log(`Payment failed for user ${user._id}`);
        // TODO: Send email notification
        break;
      }

      default:
        console.log(`Unhandled event type: ${stripeEvent.type}`);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ received: true }),
    };
  } catch (error) {
    console.error('Webhook error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Webhook handler failed', error: error.message }),
    };
  }
};
